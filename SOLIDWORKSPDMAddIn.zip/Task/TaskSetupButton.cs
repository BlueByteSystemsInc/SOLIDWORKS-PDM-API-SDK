﻿using EPDM.Interop.epdm;

namespace $safeprojectname$.Task
{
    public partial class AddIn
    {

        public void TaskSetupButton(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
