﻿using EPDM.Interop.epdm;

namespace $safeprojectname$.Task
{
    public partial class PDMFrameworkAddINSample
    {

        public void TaskSetup(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
