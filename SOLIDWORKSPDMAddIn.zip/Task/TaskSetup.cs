﻿using EPDM.Interop.epdm;

namespace $safeprojectname$
{
    public partial class AddIn
    {

        public void TaskSetup(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
