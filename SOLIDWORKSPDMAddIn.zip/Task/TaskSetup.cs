﻿using EPDM.Interop.epdm;

namespace $safeprojectname$.Task
{
    public partial class AddIn
    {

        public void TaskSetup(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
