﻿using BlueByte.SOLIDWORKS.PDMProfessional.PDMAddInFramework.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Task.SetupPages
{
    public partial class Settings : TaskSetupPage<SettingsViewModel>
    {
        public Settings()
        {
            InitializeComponent();
        }
    }
}
