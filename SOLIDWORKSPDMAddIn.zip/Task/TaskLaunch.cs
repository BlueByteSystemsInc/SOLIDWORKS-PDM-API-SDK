﻿using EPDM.Interop.epdm;

namespace $safeprojectname$.Task
{
    public partial class PDMFrameworkAddINSample
    {

        public void TaskLaunch(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
