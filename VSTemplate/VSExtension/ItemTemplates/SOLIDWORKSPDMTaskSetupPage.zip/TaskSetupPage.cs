﻿using BlueByte.SOLIDWORKS.PDMProfessional.PDMAddInFramework.Core;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : TaskSetupPage<$safeitemname$ViewModel>
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}