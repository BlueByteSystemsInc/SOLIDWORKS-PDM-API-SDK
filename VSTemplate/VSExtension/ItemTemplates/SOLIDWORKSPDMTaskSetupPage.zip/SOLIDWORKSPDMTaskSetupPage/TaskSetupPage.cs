﻿using BlueByte.SOLIDWORKS.PDMProfessional.SDK.Core;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : TaskSetupPage<$safeitemname$ViewModel>
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}