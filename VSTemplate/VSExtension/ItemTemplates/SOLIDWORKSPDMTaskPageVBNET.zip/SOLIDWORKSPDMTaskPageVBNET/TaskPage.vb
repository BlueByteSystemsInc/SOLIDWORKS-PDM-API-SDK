﻿Imports BlueByte.SOLIDWORKS.PDMProfessional.SDK.Core

Namespace $rootnamespace$
    Public Partial Class $safeitemname$
        Inherits TaskPage(Of $safeitemname$ViewModel)

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace