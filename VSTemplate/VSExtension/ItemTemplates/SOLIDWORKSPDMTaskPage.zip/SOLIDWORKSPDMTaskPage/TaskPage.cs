﻿using BlueByte.SOLIDWORKS.PDMProfessional.SDK.Core;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : TaskPage<$safeitemname$ViewModel>
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}