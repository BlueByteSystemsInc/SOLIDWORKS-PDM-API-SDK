﻿Imports EPDM.Interop.epdm

Namespace $safeprojectname$
    Partial Public Class AddIn
        Public Sub TaskSetupButton(ByRef cmdData As EdmCmd, ByRef ppoData As EdmCmdData())
        End Sub
    End Class
End Namespace
