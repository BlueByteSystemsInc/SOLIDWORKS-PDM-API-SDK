﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports EPDM.Interop.epdm

Namespace $safeprojectname$
    Partial Public Class AddIn
        Public Sub TaskRun(ByRef cmdData As EdmCmd, ByRef ppoData As EdmCmdData())
        End Sub
    End Class
End Namespace
