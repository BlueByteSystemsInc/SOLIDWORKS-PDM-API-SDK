﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EPDM.Interop.epdm;

namespace $safeprojectname$
{
    public partial class AddIn
    {

        public void TaskRun(ref EdmCmd cmdData, ref EdmCmdData[] ppoData)
        {

        }
    }
}
